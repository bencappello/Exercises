(function () {
  if (typeof TTT === "undefined") {
    window.TTT = {};
  }

  var View = TTT.View = function (game, $el) {
    this.game = game,
    this.$el = $el;
    this.setupBoard();
    this.bindEvents();
  };

  View.prototype.bindEvents = function () {
    var that = this;
    $("ul").on("click", "li", function(){
      that.makeMove($(this));
    });
  };

  View.prototype.makeMove = function ($square) {
    try {
      var currentPlayer = this.game.currentPlayer;

      this.game.playMove($square.data("pos"));
      $square.addClass(currentPlayer);
      $square.append(currentPlayer);
    } catch (e) {
      alert("Invalid Move!");
    }
    if (this.game.isOver()) {
      if (this.game.winner()) {
        alert("Congratulations " + currentPlayer + ". You win!");
      } else {
        alert("Tie game.....Boring ass people....");
      }
    }
  };

  View.prototype.setupBoard = function () {
    var $board = $("<ul class='group'></ul>");
    for (var i = 0; i < 9; i++) {
      var $li = $("<li></li>");
      $li.data("pos", [Math.floor(i / 3), i % 3]);
      $board.append($li);
      console.log($li);
      console.log($li.data("pos"));
    }
    this.$el.append($board);
  };
})();
